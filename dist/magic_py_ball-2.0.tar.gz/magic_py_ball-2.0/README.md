# Magic Py Ball
This is a simple magic 8 ball made completely using Python.
